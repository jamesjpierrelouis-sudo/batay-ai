BATAY AI — PWOJÈ ANDROID POU KONSTWI APK

Atansyon: ZIP sa a se sous kòd Android ak yon workflow GitHub Actions. Se pa yon fichye APK pare pou enstale dirèkteman.

Sa aplikasyon an fè:
- Li bay yon koòdone an kreyòl sou Android.
- Li pèmèt chwazi jiska 3 foto.
- Li prepare yon prompt an anglè pou sèn batay sinematik.
- Li louvri yon sit IA ekstèn pou eseye jenere videyo a.

Limit:
- Aplikasyon an pa genyen yon modèl videyo IA entegre.
- Sit ekstèn nan fè jenerasyon videyo a; li ka gen limit, file oswa kondisyon pa li.
- Aplikasyon an pa ka garanti 100% menm figi oswa itilizasyon gratis san limit.

POU KONSTWI APK A AK GITHUB ACTIONS:
1. Antre sou github.com epi kreye yon repository vid ki rele BatayAI. Chwazi opsyon pou ajoute yon README si ou vle, men pa mete lòt fichye yo sou menm chemen an.
2. Sou telefòn nan, dekonprese ZIP sa a.
3. Voye tout fichye ak dosye ki anndan folder batay_ai_android la nan repository a. Asire .github/workflows/build-apk.yml prezan.
4. Louvri tab Actions nan repository a. Chwazi “Build Batay AI APK” epi peze “Run workflow” si workflow la poko kòmanse otomatikman.
5. Lè workflow la fini an vèt, ouvri run sa a epi desann nan pati Artifacts. Telechaje batay-ai-debug-apk.zip.
6. Dekonprese fichye sa a; andedan w ap jwenn app-debug.apk. Louvri APK a sou Android pou enstale li. Android ka mande w otorize enstalasyon aplikasyon ki soti nan sous sa a.

Sekirite: se yon APK debug pou itilizasyon pèsonèl/tès. Pa pataje foto prive ak sèvis IA ekstèn ou pa fè konfyans.
